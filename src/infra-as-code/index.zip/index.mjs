export const handler = (event, context) => {
    console.log("Arquivo default lambdas")
}